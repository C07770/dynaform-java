package com.gfts.citi.reports;

public class DataBean {
		    private String reconPeriod;
		    private Integer fullKeys;
		   
			public String getReconPeriod() {
				return reconPeriod;
			}
			public void setReconPeriod(String reconPeriod) {
				this.reconPeriod = reconPeriod;
			}
			public Integer getFullKeys() {
				return fullKeys;
			}
			public void setFullKeys(Integer fullKeys) {
				this.fullKeys = fullKeys;
			}


}
