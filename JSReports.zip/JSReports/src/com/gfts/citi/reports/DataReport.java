package com.gfts.citi.reports;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.HashMap;

import oracle.sql.BLOB;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.ooxml.JRPptxExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

public class DataReport {

    Connection con;

    public void createReport() {
        try {
        	Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@vm-3810-df6c.nam.nsroot.net:1525:FBERCDVG", "erecon", "erecon15");
            
 /*       	Statement stmt = null;
            String query = "select jr_xml from jas_reports where JR_NAME = 'TEST_REPORT' AND ACTIVE_FLAG = 'Y'";
            		
            stmt = con.createStatement();
            String xmlstr = null;
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
            	xmlstr = rs.getString("JR_XML");
            }
        	
        	InputStream is = new ByteArrayInputStream(xmlstr.getBytes("UTF-8"));
        	JasperDesign jasperDesign = JRXmlLoader.load(is);
        	JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

        	String updaeStatement = "update JAS_REPORTS set JR_COMPILED = ?  where JR_NAME = ? AND ACTIVE_FLAG = ?";
        	
            PreparedStatement preparedStatement = con.prepareStatement(updaeStatement);
        	preparedStatement.setBytes(1, serialize(jasperReport));
            preparedStatement.setString(2, "TEST_REPORT");
            preparedStatement.setString(3, "Y");
            preparedStatement.executeUpdate();
            con.commit();
        	
        	
*/            
            System.out.println("Report generation init" + new Date().toGMTString());
            
            Statement stmt1 = null;
            String query1 = "select JR_COMPILED from jas_reports where JR_NAME = 'TEST_REPORT' AND ACTIVE_FLAG = 'Y'";
            		
            stmt1 = con.createStatement();
            oracle.sql.BLOB blob = null;
            ResultSet rs1 = stmt1.executeQuery(query1);
            while (rs1.next()) {
            	blob = (BLOB) rs1.getBlob("JR_COMPILED");
            }
            
            JasperReport jasperReport1 = (JasperReport) deserialize(blob.getBinaryStream());
            
            JasperPrint jp;
            
            System.out.println("Report generation start" + new Date().toGMTString());
            jp = JasperFillManager.fillReport(jasperReport1, new HashMap(), con);
            
            System.out.println("Report generation end & Printing start" + new Date().toGMTString());
            
            JRPptxExporter jppt= new JRPptxExporter();
            jppt.setParameter(JRExporterParameter.JASPER_PRINT, jp);
            jppt.setParameter(JRExporterParameter.OUTPUT_FILE, new File("C:/workspace/JSReports/reports/abcde.pptx"));
            jppt.exportReport();

            System.out.println("Report printing end" + new Date().toGMTString());
            
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new DataReport().createReport();
    }
    
    private static Object deserialize(InputStream stream) throws Exception {

        ObjectInputStream ois = new ObjectInputStream(stream);
        try {
            return ois.readObject();
        } finally {
            ois.close();
        }
    }


    private static  byte[] serialize(Object object) throws IOException {
    	
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(object);
        oos.close();
        return baos.toByteArray(); //new ByteArrayInputStream(baos.toByteArray());
    }
    
}
