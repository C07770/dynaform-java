package com.gfts.citi.reports;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.ooxml.JRPptxExporter;

public class ChartReport {

	   @SuppressWarnings("unchecked")
	   public static void main(String[] args) throws Exception {
	      
	      JasperReport jasperReport = JasperCompileManager
                  .compileReport("C:/eRecon Data/Jasper Reports/Charts.jrxml");

	      DataBeanList lis= new DataBeanList();
	      ArrayList<DataBean> dataList = lis.getDataBeanList();

	      JRBeanCollectionDataSource beanColDataSource =
	      new JRBeanCollectionDataSource(dataList);

	      Map parameters = new HashMap();

	      try {
//	         JasperFillManager.fillReportToFile(
//	        		 jasperReport, parameters, beanColDataSource);
	         JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport,
	                 parameters, beanColDataSource);
	         JRPptxExporter jppt= new JRPptxExporter();
	            jppt.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	            jppt.setParameter(JRExporterParameter.OUTPUT_FILE, new File("C:/jasperoutput/charts_ppt.pptx"));
	            jppt.exportReport();
//	         JasperExportManager.exportReportToPdfFile(jasperPrint,
//	                    "C:/jasperoutput/eRecon_Charts1.pdf");
	         System.out.println("Charts print done");
	      } catch (JRException e) {
	         e.printStackTrace();
	      }
	   }
}
