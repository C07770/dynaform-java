package com.gfts.citi.reports;
import java.util.ArrayList;

public class DataBeanList {
   public ArrayList getDataBeanList() {
      ArrayList dataBeanList = new ArrayList();

      
      dataBeanList.add(produce("Nov-2015", 286016));
      dataBeanList.add(produce("Dec-2015", 56664));
      dataBeanList.add(produce("Jan-2016", 7353));
      dataBeanList.add(produce("Feb-2016", 284));
      dataBeanList.add(produce("Mar-2016", 76589));
      dataBeanList.add(produce("Apr-2016", 16354));
      return dataBeanList;
   }

   /*
    * This method returns a DataBean object, with subjectName ,
    * and marks set in it.
    */
   private DataBean produce(String reconPeriod, Integer fullKeys) {
      DataBean dataBean = new DataBean();

      dataBean.setReconPeriod(reconPeriod);
      dataBean.setFullKeys(fullKeys);

      return dataBean;
   }
}